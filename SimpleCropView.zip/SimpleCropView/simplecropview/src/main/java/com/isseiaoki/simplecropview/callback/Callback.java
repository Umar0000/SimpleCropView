package com.isseiaoki.simplecropview.callback;

public interface Callback {
  void onError(Throwable e);
}
