package com.isseiaoki.simplecropview.callback;

public interface LoadCallback extends Callback {
  void onSuccess();
}
